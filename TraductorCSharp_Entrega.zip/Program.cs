using System;
using System.Collections.Generic;
using System.Text;

class Traductor
{
    static Dictionary<string, string> diccionario = new Dictionary<string, string>()
    {
        {"time", "tiempo"},
        {"person", "persona"},
        {"year", "año"},
        {"way", "camino"},
        {"day", "día"},
        {"thing", "cosa"},
        {"man", "hombre"},
        {"world", "mundo"},
        {"life", "vida"},
        {"hand", "mano"},
        {"part", "parte"},
        {"child", "niño"},
        {"eye", "ojo"},
        {"woman", "mujer"},
        {"place", "lugar"},
        {"work", "trabajo"},
        {"week", "semana"},
        {"case", "caso"},
        {"point", "punto"},
        {"government", "gobierno"},
        {"company", "empresa"}
    };

    static void Main()
    {
        int opcion;

        do
        {
            Console.WriteLine("\n==================== MENÚ ====================");
            Console.WriteLine("1. Traducir una frase");
            Console.WriteLine("2. Agregar palabras al diccionario");
            Console.WriteLine("0. Salir");
            Console.Write("Seleccione una opción: ");

            if (!int.TryParse(Console.ReadLine(), out opcion))
            {
                Console.WriteLine("Entrada inválida.");
                continue;
            }

            switch (opcion)
            {
                case 1:
                    TraducirFrase();
                    break;

                case 2:
                    AgregarPalabra();
                    break;

                case 0:
                    Console.WriteLine("Saliendo del programa...");
                    break;

                default:
                    Console.WriteLine("Opción inválida.");
                    break;
            }

        } while (opcion != 0);
    }

    static void TraducirFrase()
    {
        Console.Write("\nIngrese una frase: ");
        string frase = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(frase))
        {
            Console.WriteLine("Frase vacía.");
            return;
        }

        string[] palabras = frase.Split(' ');
        StringBuilder traduccion = new StringBuilder();

        foreach (string palabra in palabras)
        {
            string palabraLimpia = palabra.ToLower();

            if (diccionario.ContainsKey(palabraLimpia))
            {
                traduccion.Append(diccionario[palabraLimpia] + " ");
            }
            else if (diccionario.ContainsValue(palabraLimpia))
            {
                foreach (var item in diccionario)
                {
                    if (item.Value == palabraLimpia)
                    {
                        traduccion.Append(item.Key + " ");
                        break;
                    }
                }
            }
            else
            {
                traduccion.Append(palabra + " ");
            }
        }

        Console.WriteLine("\nTraducción: " + traduccion.ToString());
    }

    static void AgregarPalabra()
    {
        Console.Write("\nIngrese la palabra en inglés: ");
        string ingles = Console.ReadLine()?.ToLower();

        Console.Write("Ingrese la traducción en español: ");
        string espanol = Console.ReadLine()?.ToLower();

        if (string.IsNullOrWhiteSpace(ingles) || string.IsNullOrWhiteSpace(espanol))
        {
            Console.WriteLine("Entrada inválida.");
            return;
        }

        if (!diccionario.ContainsKey(ingles))
        {
            diccionario.Add(ingles, espanol);
            Console.WriteLine("Palabra agregada correctamente.");
        }
        else
        {
            Console.WriteLine("La palabra ya existe en el diccionario.");
        }
    }
}
