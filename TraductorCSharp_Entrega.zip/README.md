# Traductor Básico Inglés - Español en C#

## Descripción
Aplicación de consola desarrollada en C# que permite traducir frases entre inglés y español utilizando la estructura Dictionary.

## Funcionalidades
- Traducción de frases completas
- Agregar nuevas palabras al diccionario
- Menú interactivo

## Tecnologías
- C#
- .NET 8

## Autor
(Nombre del Estudiante)

## Instrucciones de Ejecución
1. Abrir la carpeta del proyecto.
2. Ejecutar el comando:
   dotnet run
