
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Conjunto para evitar títulos duplicados
        HashSet<string> titulos = new HashSet<string>();

        // Mapa para guardar libros (ISBN -> información del libro)
        Dictionary<string, string> biblioteca = new Dictionary<string, string>();

        int opcion = 0;

        while (opcion != 4)
        {
            Console.WriteLine("\n===== SISTEMA DE BIBLIOTECA =====");
            Console.WriteLine("1. Registrar libro");
            Console.WriteLine("2. Buscar libro por ISBN");
            Console.WriteLine("3. Mostrar todos los libros");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");

            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese ISBN del libro: ");
                    string isbn = Console.ReadLine();

                    Console.Write("Ingrese título del libro: ");
                    string titulo = Console.ReadLine();

                    if (titulos.Contains(titulo))
                    {
                        Console.WriteLine("El libro ya está registrado.");
                        break;
                    }

                    Console.Write("Ingrese autor del libro: ");
                    string autor = Console.ReadLine();

                    Console.Write("Ingrese año de publicación: ");
                    string anio = Console.ReadLine();

                    titulos.Add(titulo);
                    biblioteca.Add(isbn, titulo + " - " + autor + " (" + anio + ")");

                    Console.WriteLine("Libro registrado correctamente.");
                    break;

                case 2:
                    Console.Write("Ingrese ISBN a buscar: ");
                    string buscar = Console.ReadLine();

                    if (biblioteca.ContainsKey(buscar))
                    {
                        Console.WriteLine("Libro encontrado:");
                        Console.WriteLine(biblioteca[buscar]);
                    }
                    else
                    {
                        Console.WriteLine("Libro no encontrado.");
                    }
                    break;

                case 3:
                    Console.WriteLine("\nLista de libros registrados:");

                    foreach (var libro in biblioteca)
                    {
                        Console.WriteLine("ISBN: " + libro.Key + " -> " + libro.Value);
                    }

                    break;

                case 4:
                    Console.WriteLine("Saliendo del sistema...");
                    break;

                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }
}
