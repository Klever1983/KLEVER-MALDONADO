using System;

public class Nodo
{
    public int Valor;
    public Nodo Izquierdo;
    public Nodo Derecho;

    public Nodo(int valor)
    {
        Valor = valor;
        Izquierdo = null;
        Derecho = null;
    }
}

public class ArbolBST
{
    private Nodo raiz;

    public void Insertar(int valor)
    {
        raiz = InsertarRec(raiz, valor);
    }

    private Nodo InsertarRec(Nodo nodo, int valor)
    {
        if (nodo == null)
            return new Nodo(valor);

        if (valor < nodo.Valor)
            nodo.Izquierdo = InsertarRec(nodo.Izquierdo, valor);
        else if (valor > nodo.Valor)
            nodo.Derecho = InsertarRec(nodo.Derecho, valor);

        return nodo;
    }

    public bool Buscar(int valor)
    {
        return BuscarRec(raiz, valor);
    }

    private bool BuscarRec(Nodo nodo, int valor)
    {
        if (nodo == null) return false;
        if (nodo.Valor == valor) return true;

        return valor < nodo.Valor
            ? BuscarRec(nodo.Izquierdo, valor)
            : BuscarRec(nodo.Derecho, valor);
    }

    public void Eliminar(int valor)
    {
        raiz = EliminarRec(raiz, valor);
    }

    private Nodo EliminarRec(Nodo nodo, int valor)
    {
        if (nodo == null) return nodo;

        if (valor < nodo.Valor)
            nodo.Izquierdo = EliminarRec(nodo.Izquierdo, valor);
        else if (valor > nodo.Valor)
            nodo.Derecho = EliminarRec(nodo.Derecho, valor);
        else
        {
            if (nodo.Izquierdo == null && nodo.Derecho == null)
                return null;

            if (nodo.Izquierdo == null)
                return nodo.Derecho;
            else if (nodo.Derecho == null)
                return nodo.Izquierdo;

            Nodo sucesor = MinNodo(nodo.Derecho);
            nodo.Valor = sucesor.Valor;
            nodo.Derecho = EliminarRec(nodo.Derecho, sucesor.Valor);
        }

        return nodo;
    }

    public void InOrden() => InOrdenRec(raiz);
    private void InOrdenRec(Nodo nodo)
    {
        if (nodo != null)
        {
            InOrdenRec(nodo.Izquierdo);
            Console.Write(nodo.Valor + " ");
            InOrdenRec(nodo.Derecho);
        }
    }

    public void PreOrden() => PreOrdenRec(raiz);
    private void PreOrdenRec(Nodo nodo)
    {
        if (nodo != null)
        {
            Console.Write(nodo.Valor + " ");
            PreOrdenRec(nodo.Izquierdo);
            PreOrdenRec(nodo.Derecho);
        }
    }

    public void PostOrden() => PostOrdenRec(raiz);
    private void PostOrdenRec(Nodo nodo)
    {
        if (nodo != null)
        {
            PostOrdenRec(nodo.Izquierdo);
            PostOrdenRec(nodo.Derecho);
            Console.Write(nodo.Valor + " ");
        }
    }

    public int Minimo() => MinNodo(raiz).Valor;
    private Nodo MinNodo(Nodo nodo)
    {
        while (nodo.Izquierdo != null)
            nodo = nodo.Izquierdo;
        return nodo;
    }

    public int Maximo()
    {
        Nodo actual = raiz;
        while (actual.Derecho != null)
            actual = actual.Derecho;
        return actual.Valor;
    }

    public int Altura() => AlturaRec(raiz);
    private int AlturaRec(Nodo nodo)
    {
        if (nodo == null) return -1;
        return 1 + Math.Max(AlturaRec(nodo.Izquierdo), AlturaRec(nodo.Derecho));
    }

    public void Limpiar()
    {
        raiz = null;
    }
}

class Program
{
    static void Main()
    {
        ArbolBST arbol = new ArbolBST();
        int opcion, valor;

        do
        {
            Console.WriteLine("\n--- MENÚ BST ---");
            Console.WriteLine("1. Insertar");
            Console.WriteLine("2. Buscar");
            Console.WriteLine("3. Eliminar");
            Console.WriteLine("4. Recorridos");
            Console.WriteLine("5. Mínimo, Máximo y Altura");
            Console.WriteLine("6. Limpiar árbol");
            Console.WriteLine("0. Salir");
            Console.Write("Opción: ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Valor a insertar: ");
                    valor = int.Parse(Console.ReadLine());
                    arbol.Insertar(valor);
                    break;

                case 2:
                    Console.Write("Valor a buscar: ");
                    valor = int.Parse(Console.ReadLine());
                    Console.WriteLine(arbol.Buscar(valor) ? "Encontrado" : "No encontrado");
                    break;

                case 3:
                    Console.Write("Valor a eliminar: ");
                    valor = int.Parse(Console.ReadLine());
                    arbol.Eliminar(valor);
                    break;

                case 4:
                    Console.WriteLine("InOrden:");
                    arbol.InOrden();
                    Console.WriteLine("\nPreOrden:");
                    arbol.PreOrden();
                    Console.WriteLine("\nPostOrden:");
                    arbol.PostOrden();
                    Console.WriteLine();
                    break;

                case 5:
                    Console.WriteLine("Mínimo: " + arbol.Minimo());
                    Console.WriteLine("Máximo: " + arbol.Maximo());
                    Console.WriteLine("Altura: " + arbol.Altura());
                    break;

                case 6:
                    arbol.Limpiar();
                    Console.WriteLine("Árbol limpiado.");
                    break;
            }

        } while (opcion != 0);
    }
}
