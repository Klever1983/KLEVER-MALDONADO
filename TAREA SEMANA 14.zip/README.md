# Árbol Binario de Búsqueda (BST) en C#

Aplicación de consola que implementa un BST con:

- Inserción
- Búsqueda
- Eliminación
- Recorridos (InOrden, PreOrden, PostOrden)
- Mínimo, Máximo y Altura
- Limpieza del árbol

## Cómo ejecutar

```bash
dotnet run
```
