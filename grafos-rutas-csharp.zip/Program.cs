using System;
using System.Collections.Generic;

class Grafo
{
    private Dictionary<string, List<(string, int)>> adyacencia = new Dictionary<string, List<(string, int)>>();

    public void AgregarCiudad(string ciudad)
    {
        if (!adyacencia.ContainsKey(ciudad))
            adyacencia[ciudad] = new List<(string, int)>();
    }

    public void AgregarVuelo(string origen, string destino, int costo)
    {
        adyacencia[origen].Add((destino, costo));
        adyacencia[destino].Add((origen, costo)); // bidireccional
    }

    public void MostrarGrafo()
    {
        foreach (var ciudad in adyacencia)
        {
            Console.WriteLine($"Ciudad {ciudad.Key}:");
            foreach (var vuelo in ciudad.Value)
            {
                Console.WriteLine($"  -> {vuelo.Item1} (${vuelo.Item2})");
            }
        }
    }

    public void Dijkstra(string inicio)
    {
        var distancias = new Dictionary<string, int>();
        var visitados = new HashSet<string>();

        foreach (var nodo in adyacencia.Keys)
            distancias[nodo] = int.MaxValue;

        distancias[inicio] = 0;

        while (visitados.Count < adyacencia.Count)
        {
            string nodoActual = null;
            int menorDistancia = int.MaxValue;

            foreach (var nodo in distancias)
            {
                if (!visitados.Contains(nodo.Key) && nodo.Value < menorDistancia)
                {
                    nodoActual = nodo.Key;
                    menorDistancia = nodo.Value;
                }
            }

            if (nodoActual == null) break;

            visitados.Add(nodoActual);

            foreach (var vecino in adyacencia[nodoActual])
            {
                int nuevaDistancia = distancias[nodoActual] + vecino.Item2;
                if (nuevaDistancia < distancias[vecino.Item1])
                {
                    distancias[vecino.Item1] = nuevaDistancia;
                }
            }
        }

        Console.WriteLine("\nCostos mínimos desde " + inicio);
        foreach (var d in distancias)
        {
            Console.WriteLine($"{d.Key}: ${d.Value}");
        }
    }
}

class Program
{
    static void Main()
    {
        Grafo grafo = new Grafo();

        grafo.AgregarCiudad("Quito");
        grafo.AgregarCiudad("Guayaquil");
        grafo.AgregarCiudad("Cuenca");
        grafo.AgregarCiudad("Loja");

        grafo.AgregarVuelo("Quito", "Guayaquil", 100);
        grafo.AgregarVuelo("Quito", "Cuenca", 120);
        grafo.AgregarVuelo("Guayaquil", "Loja", 80);
        grafo.AgregarVuelo("Cuenca", "Loja", 50);

        grafo.MostrarGrafo();

        grafo.Dijkstra("Quito");

        Console.ReadLine();
    }
}
