# Grafos - Rutas de Transporte en C#

Este proyecto implementa un grafo para simular rutas de transporte entre ciudades y calcular el costo mínimo usando el algoritmo de Dijkstra.

## Funcionalidades
- Representación de ciudades como nodos
- Conexiones como aristas con peso (costo)
- Cálculo de rutas más económicas

## Ejecución
1. Abrir el proyecto en Visual Studio
2. Ejecutar el archivo Program.cs
3. Ver resultados en consola

## Ejemplo
Se calcula el costo mínimo desde Quito hacia otras ciudades.

## Autor
Estudiante de Estructura de Datos
